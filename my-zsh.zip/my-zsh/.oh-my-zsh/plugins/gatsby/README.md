# gatsby autocomplete plugin

* Adds autocomplete options for all gatsby commands.

## Requirements

In order to make this work, you will need to have gatsby set up in your path.
